"""
Onryo – optional package manager.

Docker and MEGAcmd (MEGA's CLI sync client) are optional components.
install.sh can skip either at setup time, and this module lets the web
GUI install or remove them afterward -- all privileged apt/systemctl
work goes through the narrow-scope privileged_helper, same pattern as
network_manager and ap_manager.
"""

from __future__ import annotations

import logging
import shutil
import subprocess

logger = logging.getLogger("onryo.package_manager")

HELPER_BIN = "/opt/onryo/backend/privileged_helper/helper.sh"

# Install/removal can take minutes (apt-get update + package download),
# unlike the other narrow helper actions which are near-instant.
_INSTALL_TIMEOUT = 600


def _helper(action: str, timeout: int = 30) -> tuple[bool, str]:
    result = subprocess.run(
        ["sudo", HELPER_BIN, action],
        capture_output=True, text=True, timeout=timeout,
    )
    if result.returncode != 0:
        logger.warning("helper %s failed: %s", action, result.stderr.strip())
        return False, (result.stderr.strip() or result.stdout.strip())
    return True, result.stdout.strip()


def _is_installed(binary: str) -> bool:
    return shutil.which(binary) is not None


def get_status() -> dict:
    """Return install status for every optional package this GUI manages."""
    return {
        "docker": {
            "installed": _is_installed("docker"),
            "label": "Docker",
            "description": "Container runtime used for plugin/container services.",
        },
        "megacmd": {
            "installed": _is_installed("mega-cmd"),
            "label": "MEGAcmd",
            "description": "MEGA's command-line client for MEGA cloud sync.",
        },
    }


def install_docker() -> tuple[bool, str]:
    ok, msg = _helper("install-docker", timeout=_INSTALL_TIMEOUT)
    return ok, msg or ("Docker installed" if ok else "Docker install failed")


def remove_docker() -> tuple[bool, str]:
    ok, msg = _helper("remove-docker", timeout=_INSTALL_TIMEOUT)
    return ok, msg or ("Docker removed" if ok else "Docker removal failed")


def install_megacmd() -> tuple[bool, str]:
    ok, msg = _helper("install-megacmd", timeout=_INSTALL_TIMEOUT)
    return ok, msg or ("MEGAcmd installed" if ok else "MEGAcmd install failed")


def remove_megacmd() -> tuple[bool, str]:
    ok, msg = _helper("remove-megacmd", timeout=_INSTALL_TIMEOUT)
    return ok, msg or ("MEGAcmd removed" if ok else "MEGAcmd removal failed")

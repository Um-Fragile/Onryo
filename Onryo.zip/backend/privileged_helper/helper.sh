#!/bin/bash
# Onryo – privileged helper (root-owned, narrow scope)
# Called by the non-root onryo service user to perform the handful of
# privileged operations the framework needs.  Never do anything outside
# this explicit allow-list.

set -euo pipefail
LOGFILE="/var/log/onryo/helper.log"
mkdir -p "$(dirname "$LOGFILE")"

log() { echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) [helper] $*" | tee -a "$LOGFILE" >&2; }

ACTION="${1:-}"
shift || true

case "$ACTION" in

  # --- systemd unit management -------------------------------------------
  enable)
    UNIT="$1"
    [[ "$UNIT" == onryo-svc-* ]] || { log "DENIED: enable $UNIT"; exit 1; }
    log "enable $UNIT"
    systemctl enable --now "$UNIT"
    ;;

  disable)
    UNIT="$1"
    [[ "$UNIT" == onryo-svc-* ]] || { log "DENIED: disable $UNIT"; exit 1; }
    log "disable $UNIT"
    systemctl disable --now "$UNIT"
    ;;

  start)
    UNIT="$1"
    [[ "$UNIT" == onryo-* ]] || { log "DENIED: start $UNIT"; exit 1; }
    log "start $UNIT"
    systemctl start "$UNIT"
    ;;

  stop)
    UNIT="$1"
    [[ "$UNIT" == onryo-* ]] || { log "DENIED: stop $UNIT"; exit 1; }
    log "stop $UNIT"
    systemctl stop "$UNIT"
    ;;

  write-unit)
    SRC="$1"
    DST="$2"
    [[ "$DST" == /etc/systemd/system/onryo-svc-* ]] || { log "DENIED: write-unit $DST"; exit 1; }
    log "write-unit $SRC -> $DST"
    install -m 644 "$SRC" "$DST"
    systemctl daemon-reload
    ;;

  # --- networking (bridge) -----------------------------------------------
  bridge-add)
    BRIDGE="$1"
    IFACE="$2"
    log "bridge-add $IFACE -> $BRIDGE"
    ip link add name "$BRIDGE" type bridge 2>/dev/null || true
    ip link set "$BRIDGE" up
    ip link set "$IFACE" master "$BRIDGE"
    ;;

  bridge-remove)
    BRIDGE="$1"
    IFACE="$2"
    log "bridge-remove $IFACE from $BRIDGE"
    ip link set "$IFACE" nomaster
    ;;

  wifi-reload)
    log "wifi-reload"
    systemctl reload-or-restart NetworkManager
    ;;

  # --- system AP (Onryo ap_manager.py) -----------------------------------
  # These are the privileged steps APManager.start()/stop() cannot do as
  # the non-root onryo user.  Channel switching for both the system AP
  # and the Vision plugin AP both go through ap-chan-switch.

  ap-setup)
    # ap-setup <iface> <ip/prefix>
    # Flush old addresses, assign AP IP, bring the interface up.
    IFACE="$1"
    ADDR="$2"   # e.g. 192.168.42.1/24
    [[ "$IFACE" =~ ^[a-zA-Z0-9_]+$ ]] || { log "DENIED: bad iface $IFACE"; exit 1; }
    log "ap-setup $IFACE $ADDR"
    ip addr flush dev "$IFACE"
    ip addr add "$ADDR" dev "$IFACE"
    ip link set "$IFACE" up
    ;;

  ap-teardown)
    # ap-teardown <iface>
    IFACE="$1"
    [[ "$IFACE" =~ ^[a-zA-Z0-9_]+$ ]] || { log "DENIED: bad iface $IFACE"; exit 1; }
    log "ap-teardown $IFACE"
    systemctl stop hostapd  2>/dev/null || true
    systemctl stop dnsmasq  2>/dev/null || true
    ip addr flush dev "$IFACE" 2>/dev/null || true
    ;;

  ap-start-daemons)
    # ap-start-daemons
    # (Re)start hostapd and dnsmasq after ap-setup has configured the iface.
    log "ap-start-daemons"
    systemctl restart hostapd
    systemctl restart dnsmasq
    echo 1 > /proc/sys/net/ipv4/ip_forward
    ;;

  ap-chan-switch)
    # ap-chan-switch <iface> <freq_mhz> [<center_freq_mhz>] [ht|vht]
    # Shared by both the system AP and the Vision plugin AP.
    IFACE="$1"
    FREQ="$2"
    CENTER="${3:-0}"
    MODE="${4:-ht}"
    [[ "$IFACE" =~ ^[a-zA-Z0-9_]+$ ]] || { log "DENIED: bad iface $IFACE";  exit 1; }
    [[ "$FREQ"  =~ ^[0-9]+$ ]]         || { log "DENIED: bad freq $FREQ";    exit 1; }
    [[ "$CENTER" =~ ^[0-9]+$ ]]        || { log "DENIED: bad center $CENTER"; exit 1; }
    log "ap-chan-switch $IFACE freq=$FREQ center=$CENTER mode=$MODE"
    if [[ "$MODE" == "vht" && "$CENTER" != "0" ]]; then
      hostapd_cli -i "$IFACE" chan_switch 10 "$FREQ" \
        center_freq1="$CENTER" sec_channel_offset=0 bandwidth=80 vht
    else
      hostapd_cli -i "$IFACE" chan_switch 10 "$FREQ" sec_channel_offset=0 ht
    fi
    ;;

  ap-set-txpower)
    IFACE="$1"
    DBM="$2"
    [[ "$IFACE" =~ ^[a-zA-Z0-9_]+$ ]] || { log "DENIED: bad iface"; exit 1; }
    [[ "$DBM"   =~ ^[0-9]+$ ]]         || { log "DENIED: bad txpower"; exit 1; }
    log "ap-set-txpower $IFACE ${DBM}dBm"
    iw dev "$IFACE" set txpower fixed "$((DBM * 100))"
    ;;

  ap-monitor-on)
    # Put interface into monitor mode (for Vision pentest scanner)
    IFACE="$1"
    [[ "$IFACE" =~ ^[a-zA-Z0-9_]+$ ]] || { log "DENIED: bad iface"; exit 1; }
    log "ap-monitor-on $IFACE"
    ip link set "$IFACE" down
    iw dev "$IFACE" set type monitor
    ip link set "$IFACE" up
    ;;

  ap-monitor-off)
    IFACE="$1"
    [[ "$IFACE" =~ ^[a-zA-Z0-9_]+$ ]] || { log "DENIED: bad iface"; exit 1; }
    log "ap-monitor-off $IFACE"
    ip link set "$IFACE" down
    iw dev "$IFACE" set type managed
    ip link set "$IFACE" up
    ;;

  # --- optional packages: Docker ------------------------------------------
  # Idempotent install/remove so the web GUI can offer Docker as an
  # optional component the operator can add or take away after setup.
  install-docker)
    log "install-docker"
    if command -v docker &>/dev/null; then
      log "Docker already installed"
    else
      curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
      echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] \
        https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" \
        > /etc/apt/sources.list.d/docker.list
      apt-get update -qq
      DEBIAN_FRONTEND=noninteractive apt-get install -y \
        docker-ce docker-ce-cli containerd.io docker-compose-plugin
      usermod -aG docker onryo 2>/dev/null || true
      log "Docker installed"
    fi
    ;;

  remove-docker)
    log "remove-docker"
    systemctl stop docker.service docker.socket 2>/dev/null || true
    DEBIAN_FRONTEND=noninteractive apt-get remove -y --purge \
      docker-ce docker-ce-cli containerd.io docker-compose-plugin 2>/dev/null || true
    rm -f /etc/apt/sources.list.d/docker.list /usr/share/keyrings/docker-archive-keyring.gpg
    log "Docker removed"
    ;;

  # --- optional packages: MEGAcmd -----------------------------------------
  # MEGAcmd is MEGA's CLI (non-UI) client for MEGA sync, installed from
  # MEGA's own apt repository. Idempotent install/remove, same pattern as
  # Docker above.
  install-megacmd)
    log "install-megacmd"
    if command -v mega-cmd &>/dev/null; then
      log "MEGAcmd already installed"
    else
      DIST_VER=$(. /etc/os-release && echo "$VERSION_ID")
      mkdir -p /etc/apt/keyrings
      curl -fsSL https://mega.nz/keys/MEGA_signing.key | gpg --dearmor -o /etc/apt/keyrings/meganz-archive-keyring.gpg
      cat > /etc/apt/sources.list.d/megaio.sources <<EOF
Types: deb
URIs: https://mega.nz/linux/repo/xUbuntu_${DIST_VER}/
Suites: ./
Signed-By: /etc/apt/keyrings/meganz-archive-keyring.gpg
EOF
      apt-get update -qq
      DEBIAN_FRONTEND=noninteractive apt-get install -y megacmd
      log "MEGAcmd installed"
    fi
    ;;

  remove-megacmd)
    log "remove-megacmd"
    DEBIAN_FRONTEND=noninteractive apt-get remove -y --purge megacmd 2>/dev/null || true
    rm -f /etc/apt/sources.list.d/megaio.sources /etc/apt/keyrings/meganz-archive-keyring.gpg
    log "MEGAcmd removed"
    ;;

  pkg-status)
    # pkg-status – report installed/not-installed for optional components
    DOCKER_INSTALLED=$(command -v docker &>/dev/null && echo 1 || echo 0)
    MEGACMD_INSTALLED=$(command -v mega-cmd &>/dev/null && echo 1 || echo 0)
    echo "docker=${DOCKER_INSTALLED}"
    echo "megacmd=${MEGACMD_INSTALLED}"
    ;;

  # --- input lockout -------------------------------------------------------
  lockout-release)
    log "lockout-release – signaling input guard"
    systemctl kill --signal=SIGTERM onryo-input-guard.service 2>/dev/null || true
    ;;

  # --- uninstall -----------------------------------------------------------
  uninstall)
    log "uninstall triggered"
    /opt/onryo/uninstall.sh "$@"
    ;;

  *)
    log "Unknown action: $ACTION"
    exit 1
    ;;
esac

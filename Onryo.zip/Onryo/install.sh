#!/bin/bash
# =============================================================================
# Onryo – install.sh
# Run as root (or via sudo). Idempotent – safe to re-run.
# Usage: sudo ./install.sh [--non-interactive --config preseed.json]
# =============================================================================

set -euo pipefail

ONRYO_USER="onryo"
ONRYO_HOME="/opt/onryo"
ETC_DIR="/etc/onryo"
LOG_DIR="/var/log/onryo"
INSTALL_LOG="$LOG_DIR/install.log"
SYSTEMD_DIR="/etc/systemd/system"
REPO_DIR="$(cd "$(dirname "$0")" && pwd)"

NON_INTERACTIVE=0
PRESEED=""

# ---- Argument parsing -------------------------------------------------------
while [[ $# -gt 0 ]]; do
  case "$1" in
    --non-interactive) NON_INTERACTIVE=1 ;;
    --config) PRESEED="$2"; shift ;;
    *) echo "Unknown argument: $1"; exit 1 ;;
  esac
  shift
done

# ---- Logging ----------------------------------------------------------------
mkdir -p "$LOG_DIR"
exec > >(tee -a "$INSTALL_LOG") 2>&1

log()  { echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) [install] $*"; }
die()  { log "ERROR: $*"; exit 1; }
ask()  {
  local prompt="$1" default="$2" var="$3"
  if [[ $NON_INTERACTIVE -eq 1 ]]; then
    eval "$var='$default'"
    return
  fi
  read -rp "$prompt [$default]: " input
  eval "$var='${input:-$default}'"
}
# preseed_get KEY DEFAULT – read a top-level key out of the preseed JSON
# (if one was supplied via --config), falling back to DEFAULT otherwise.
# Returns the value as a plain string ("true"/"false" for booleans).
preseed_get() {
  local key="$1" default="$2"
  if [[ -z "$PRESEED" || ! -f "$PRESEED" ]]; then
    echo "$default"
    return
  fi
  python3 -c "
import json
try:
    data = json.load(open('$PRESEED'))
    val = data.get('$key', '$default')
    print(str(val).lower() if isinstance(val, bool) else val)
except Exception:
    print('$default')
" 2>/dev/null || echo "$default"
}

log "=== Onryo installer starting ==="

# ---- Pre-flight checks ------------------------------------------------------
[[ "$(id -u)" -eq 0 ]] || die "Must run as root"

OS_ID=$(. /etc/os-release && echo "$ID")
[[ "$OS_ID" == "ubuntu" ]] || log "WARN: Expected Ubuntu, got $OS_ID – proceeding anyway"

ARCH=$(uname -m)
log "Architecture: $ARCH | OS: $OS_ID"

# Count wireless adapters
WIFI_COUNT=$(ls /sys/class/ieee80211 2>/dev/null | wc -l)
ETH_COUNT=$(ls /sys/class/net | grep -E '^(eth|en)' | wc -l || true)
log "Detected $WIFI_COUNT wireless adapter(s), $ETH_COUNT ethernet adapter(s)"
if [[ $WIFI_COUNT -lt 3 ]]; then
  log "WARN: Expected 3 wireless adapters, found $WIFI_COUNT. If an adapter is plugged in but not listed here, its driver probably isn't installed yet -- driver_setup.sh (run automatically below) handles the TP-Link Archer T3U/Nano and ALFA AWUS036ACH/AXML adapters; re-run it standalone any time."
fi

# ---- Install OS dependencies ------------------------------------------------
log "Installing OS dependencies..."
apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y \
  python3 python3-venv python3-pip \
  sqlite3 \
  hostapd dnsmasq \
  network-manager \
  udev \
  iproute2 iputils-ping \
  curl wget git \
  build-essential \
  --no-install-recommends

# ---- Wireless adapter drivers (TP-Link Archer T3U/Nano, ALFA AWUS036ACH/AC,
#      ALFA AWUS036AXM/AXML) -------------------------------------------------
# Best-effort: a driver build failure here must not abort the rest of the
# install -- re-run driver_setup.sh standalone later (e.g. after a kernel
# upgrade, or once matching kernel headers are available). This is the base
# project's job; plugins never detect chipsets or install drivers themselves.
if [[ -x "$REPO_DIR/driver_setup.sh" ]]; then
  log "Setting up wireless adapter drivers (88x2bu / 88XXau / mt7921u)..."
  "$REPO_DIR/driver_setup.sh" || log "WARNING: driver_setup.sh reported problems; re-run it manually to retry, or use the Network page's 'Install/Update Wireless Drivers' button once Onryo is running."
fi

# ---- Docker (optional) -------------------------------------------------------
if [[ $NON_INTERACTIVE -eq 0 ]]; then
  read -rp "Install Docker? (yes/no) [yes]: " INSTALL_DOCKER_ANSWER
  INSTALL_DOCKER_ANSWER="${INSTALL_DOCKER_ANSWER:-yes}"
else
  INSTALL_DOCKER_ANSWER=$(preseed_get "install_docker" "true")
fi
case "$INSTALL_DOCKER_ANSWER" in
  yes|true|1) INSTALL_DOCKER=1 ;;
  *) INSTALL_DOCKER=0 ;;
esac

if [[ $INSTALL_DOCKER -eq 1 ]]; then
  if ! command -v docker &>/dev/null; then
    log "Installing Docker..."
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] \
      https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" \
      > /etc/apt/sources.list.d/docker.list
    apt-get update -qq
    DEBIAN_FRONTEND=noninteractive apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
  else
    log "Docker already installed: $(docker --version)"
  fi
else
  log "Skipping Docker install (can be installed later from the web GUI's System page)."
fi

# ---- MEGAcmd (optional) -------------------------------------------------------
# MEGAcmd is MEGA's CLI (non-UI) client for MEGA cloud sync. Opt-in, same
# pattern as Docker above -- can also be installed/removed later from the GUI.
if [[ $NON_INTERACTIVE -eq 0 ]]; then
  read -rp "Install MEGAcmd (CLI for MEGA sync)? (yes/no) [no]: " INSTALL_MEGACMD_ANSWER
  INSTALL_MEGACMD_ANSWER="${INSTALL_MEGACMD_ANSWER:-no}"
else
  INSTALL_MEGACMD_ANSWER=$(preseed_get "install_megacmd" "false")
fi
case "$INSTALL_MEGACMD_ANSWER" in
  yes|true|1) INSTALL_MEGACMD=1 ;;
  *) INSTALL_MEGACMD=0 ;;
esac

if [[ $INSTALL_MEGACMD -eq 1 ]]; then
  if ! command -v mega-cmd &>/dev/null; then
    log "Installing MEGAcmd..."
    DIST_VER=$(. /etc/os-release && echo "$VERSION_ID")
    mkdir -p /etc/apt/keyrings
    curl -fsSL https://mega.nz/keys/MEGA_signing.key | gpg --dearmor -o /etc/apt/keyrings/meganz-archive-keyring.gpg
    cat > /etc/apt/sources.list.d/megaio.sources <<EOF
Types: deb
URIs: https://mega.nz/linux/repo/xUbuntu_${DIST_VER}/
Suites: ./
Signed-By: /etc/apt/keyrings/meganz-archive-keyring.gpg
EOF
    apt-get update -qq
    DEBIAN_FRONTEND=noninteractive apt-get install -y megacmd || log "WARN: MEGAcmd install failed – can retry later from the web GUI's System page."
  else
    log "MEGAcmd already installed"
  fi
else
  log "Skipping MEGAcmd install (can be installed later from the web GUI's System page)."
fi

# ---- Create onryo user and directories --------------------------------------
if ! id "$ONRYO_USER" &>/dev/null; then
  log "Creating system user: $ONRYO_USER"
  useradd --system --home-dir "$ONRYO_HOME" --shell /usr/sbin/nologin --create-home "$ONRYO_USER"
else
  log "User $ONRYO_USER already exists"
fi

# Add to docker group (only if Docker was installed)
if [[ $INSTALL_DOCKER -eq 1 ]]; then
  usermod -aG docker "$ONRYO_USER" || true
fi

mkdir -p "$ONRYO_HOME" "$ETC_DIR" "$LOG_DIR"
chown -R "$ONRYO_USER:$ONRYO_USER" "$ONRYO_HOME" "$LOG_DIR"
chown root:root "$ETC_DIR"
chmod 755 "$ETC_DIR"

# ---- Copy repo files --------------------------------------------------------
log "Copying framework files to $ONRYO_HOME..."
rsync -a --exclude='.git' "$REPO_DIR/" "$ONRYO_HOME/"
chown -R "$ONRYO_USER:$ONRYO_USER" "$ONRYO_HOME"

# Privileged helper must be root-owned, not writable by onryo user
chown root:root "$ONRYO_HOME/backend/privileged_helper/helper.sh"
chmod 755 "$ONRYO_HOME/backend/privileged_helper/helper.sh"

# ---- Python virtualenv + dependencies ----------------------------------------
log "Setting up Python virtualenv..."
python3 -m venv "$ONRYO_HOME/venv"
"$ONRYO_HOME/venv/bin/pip" install --quiet --upgrade pip
"$ONRYO_HOME/venv/bin/pip" install --quiet \
  fastapi uvicorn[standard] \
  pydantic \
  pyyaml \
  docker \
  aiofiles

# ---- sudoers entry for privileged helper ------------------------------------
SUDOERS_FILE="/etc/sudoers.d/onryo"
cat > "$SUDOERS_FILE" <<EOF
# Onryo – allow the onryo user to call the privileged helper
$ONRYO_USER ALL=(root) NOPASSWD: $ONRYO_HOME/backend/privileged_helper/helper.sh
EOF
chmod 440 "$SUDOERS_FILE"
log "Sudoers entry written: $SUDOERS_FILE"

# ---- Interactive configuration prompts -------------------------------------
log "--- Configuration ---"

# Admin password
if [[ $NON_INTERACTIVE -eq 0 ]]; then
  while true; do
    read -rsp "Admin GUI password: " ADMIN_PW; echo
    read -rsp "Confirm password:   " ADMIN_PW2; echo
    [[ "$ADMIN_PW" == "$ADMIN_PW2" ]] && break
    echo "Passwords do not match. Try again."
  done
else
  ADMIN_PW="${PRESEED_ADMIN_PW:-changeme}"
fi
ADMIN_HASH=$(python3 -c "import hashlib; print(hashlib.sha256('$ADMIN_PW'.encode()).hexdigest())")

ask "Initial Wi-Fi SSID (client adapter)"     ""     WIFI_SSID
ask "Initial Wi-Fi password"                   ""     WIFI_PSK
ask "AP hotspot SSID"                          "OnryoAP"  AP_SSID
ask "AP hotspot password"                      "onryo1234" AP_PSK
ask "Enable input lockout? (yes/no)"           "yes"  INPUT_LOCKOUT
ask "Plugin scan directory"                    "/opt/onryo/plugins" SCAN_DIR

INPUT_LOCKOUT_BOOL=1
[[ "$INPUT_LOCKOUT" == "no" ]] && INPUT_LOCKOUT_BOOL=0

# ---- Adapter discovery + friendly names ------------------------------------
log "Running automatic network device discovery..."

# Discover every physical adapter, generate default friendly names, and
# suggest roles for wireless adapters only. Ethernet is NEVER auto-assigned
# a role here -- this deployment is wireless-first; ethernet can still be
# configured later from the web GUI if/when it's available.
DISCOVERY_JSON=$(ONRYO_NET_ROLES="$ETC_DIR/network-roles.json" \
                 ONRYO_NET_NAMES="$ETC_DIR/network-names.json" \
                 PYTHONPATH="$REPO_DIR/backend" \
                 python3 -c "
import json
from network_manager.network_manager import discover_and_autofill
print(json.dumps(discover_and_autofill(assign_roles=True)))
")
echo "$DISCOVERY_JSON" | python3 -c "
import json, sys
adapters = json.load(sys.stdin)
print('')
print('Discovered adapters:')
for a in adapters:
    print(f\"  {a['friendly_name']:<22} {a['name']:<14} {a['type']:<9} role={a['role']:<10} mac={a['mac']}\")
print('')
print('Default friendly names and wireless-adapter role suggestions have been saved.')
print('Review/adjust roles, names, and (optionally) assign ethernet roles from the web GUI once Onryo is running.')
"

if [[ $NON_INTERACTIVE -eq 0 ]]; then
  echo ""
  echo "You can rename adapters or override roles now, or later from the web GUI."
  read -rp "Override any adapter roles now? (yes/no) [no]: " OVERRIDE_ROLES
  if [[ "$OVERRIDE_ROLES" == "yes" ]]; then
    while true; do
      read -rp "Adapter name to change (blank to finish): " OV_IFACE
      [[ -z "$OV_IFACE" ]] && break
      read -rp "New role for $OV_IFACE (uplink/client/ap/pentest/unassigned): " OV_ROLE
      OV_MAC=$(cat "/sys/class/net/$OV_IFACE/address" 2>/dev/null || echo "")
      if [[ -z "$OV_MAC" ]]; then
        echo "Could not resolve MAC for $OV_IFACE – skipping"
        continue
      fi
      PYTHONPATH="$REPO_DIR/backend" ONRYO_NET_ROLES="$ETC_DIR/network-roles.json" \
        python3 -c "
from network_manager.network_manager import set_role
set_role('$OV_MAC', '$OV_ROLE')
print('Set $OV_IFACE ($OV_MAC) -> $OV_ROLE')
"
    done
  fi
fi

# ---- Write config files ------------------------------------------------------
log "Writing /etc/onryo config files..."

mkdir -p "$SCAN_DIR"
chown "$ONRYO_USER:$ONRYO_USER" "$SCAN_DIR"

# directories.json
cat > "$ETC_DIR/directories.json" <<EOF
{
  "directories": ["$SCAN_DIR", "$ONRYO_HOME/containers"]
}
EOF

# wifi-networks.json
cat > "$ETC_DIR/wifi-networks.json" <<EOF
[
  {"ssid": "$WIFI_SSID", "psk": "$WIFI_PSK", "priority": 10, "enabled": true}
]
EOF

# ap-config.json
cat > "$ETC_DIR/ap-config.json" <<EOF
{
  "ssid": "$AP_SSID",
  "password": "$AP_PSK",
  "channel": 6,
  "band": "bg"
}
EOF

# input-lockout.json
cat > "$ETC_DIR/input-lockout.json" <<EOF
{
  "enabled": $( [[ $INPUT_LOCKOUT_BOOL -eq 1 ]] && echo "true" || echo "false" ),
  "grace_period_seconds": 5
}
EOF

# network-roles.json and network-names.json were already written by the
# automatic discovery step above (discover_and_autofill) -- do NOT
# overwrite them here. Ethernet adapters remain 'unassigned' until the
# operator configures them explicitly from the web GUI.
chown root:root "$ETC_DIR/network-roles.json" "$ETC_DIR/network-names.json" 2>/dev/null || true

# Store admin hash in DB via Python (DB created on first app start)
cat > /tmp/onryo_init_db.py <<'PYEOF'
import sys; sys.path.insert(0, '/opt/onryo')
from backend.db.database import init_db, get_db
init_db()
import os
with get_db() as db:
    db.execute("INSERT INTO app_settings (key,value) VALUES ('admin_pw_hash',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
               (os.environ['ADMIN_HASH'],))
PYEOF
ADMIN_HASH="$ADMIN_HASH" "$ONRYO_HOME/venv/bin/python" /tmp/onryo_init_db.py
chown "$ONRYO_USER:$ONRYO_USER" "$ONRYO_HOME/onryo.db" 2>/dev/null || true

# ---- Install systemd unit files ----------------------------------------------
log "Installing systemd units..."
for unit in "$REPO_DIR/systemd/"*; do
  install -m 644 "$unit" "$SYSTEMD_DIR/"
done

# Update paths in units to point to actual install location
for unit in "$SYSTEMD_DIR"/onryo-*.{service,timer}; do
  sed -i "s|/opt/onryo|$ONRYO_HOME|g" "$unit" 2>/dev/null || true
done

systemctl daemon-reload

# Enable (but don't start yet – let boot ordering handle it)
systemctl enable onryo-scan.timer
systemctl enable onryo-scan.service
systemctl enable onryo-netmgr.service
systemctl enable onryo-core.service
systemctl enable onryo-input-guard.service

# ---- Run first scan ---------------------------------------------------------
log "Running initial discovery scan..."
sudo -u "$ONRYO_USER" ONRYO_DB="$ONRYO_HOME/onryo.db" \
  "$ONRYO_HOME/venv/bin/python" -m backend.scanner.scanner || log "WARN: Initial scan failed – will retry on boot"

# ---- Minecraft stack prompt -------------------------------------------------
if [[ $INSTALL_DOCKER -eq 1 ]]; then
  if [[ $NON_INTERACTIVE -eq 0 ]]; then
    read -rp "Enable Minecraft server now? (yes/no) [no]: " MC_ENABLE
  else
    MC_ENABLE="no"
  fi
else
  MC_ENABLE="no"
  log "Docker was not installed – skipping Minecraft server (it requires Docker; enable Docker from the web GUI first if you want it)."
fi

if [[ "$MC_ENABLE" == "yes" ]]; then
  sudo -u "$ONRYO_USER" ONRYO_DB="$ONRYO_HOME/onryo.db" python3 - <<'PYEOF'
import sys; sys.path.insert(0, '/opt/onryo')
from backend.db.database import get_db
with get_db() as db:
    db.execute("UPDATE services SET enabled=1 WHERE name='Minecraft Server'")
PYEOF
  log "Minecraft server enabled."
fi

# ---- Final summary -----------------------------------------------------------
LAN_IP=$(hostname -I | awk '{print $1}')
log "=== Onryo installation complete ==="
echo ""
echo "  Web GUI:      http://$LAN_IP:8080"
echo "  AP SSID:      $AP_SSID"
echo "  AP Password:  $AP_PSK"
echo "  Install log:  $INSTALL_LOG"
echo ""
if [[ $INSTALL_DOCKER -eq 0 ]]; then
  echo "  Docker was NOT installed. Install it anytime from System > Optional Components in the web GUI."
fi
if [[ $INSTALL_MEGACMD -eq 0 ]]; then
  echo "  MEGAcmd was NOT installed. Install it anytime from System > Optional Components in the web GUI."
fi
echo ""
echo "  Start Onryo now: systemctl start onryo-core"
echo ""

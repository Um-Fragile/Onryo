"""
Onryo – Network manager.
Handles adapter-role mapping, bridge building, Wi-Fi client list,
and AP configuration.  Privileged operations are delegated to the helper.
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
from pathlib import Path

logger = logging.getLogger("onryo.network_manager")

ROLES_FILE = os.environ.get("ONRYO_NET_ROLES", "/etc/onryo/network-roles.json")
WIFI_FILE  = os.environ.get("ONRYO_WIFI_FILE",  "/etc/onryo/wifi-networks.json")
NAMES_FILE = os.environ.get("ONRYO_NET_NAMES",  "/etc/onryo/network-names.json")
HELPER_BIN = os.environ.get("ONRYO_HELPER",     "/opt/onryo/privileged_helper/helper.sh")

VALID_ROLES = {"uplink", "client", "ap", "pentest"}


# ---------------------------------------------------------------------------
# Role / adapter helpers
# ---------------------------------------------------------------------------

def load_roles() -> dict:
    """Return {mac: role} mapping from /etc/onryo/network-roles.json."""
    try:
        return json.loads(Path(ROLES_FILE).read_text())
    except FileNotFoundError:
        return {}


def save_roles(roles: dict) -> None:
    Path(ROLES_FILE).parent.mkdir(parents=True, exist_ok=True)
    Path(ROLES_FILE).write_text(json.dumps(roles, indent=2))


# ---------------------------------------------------------------------------
# Friendly names
# ---------------------------------------------------------------------------

def load_names() -> dict:
    """Return {mac: friendly_name} mapping from /etc/onryo/network-names.json."""
    try:
        return json.loads(Path(NAMES_FILE).read_text())
    except FileNotFoundError:
        return {}


def save_names(names: dict) -> None:
    Path(NAMES_FILE).parent.mkdir(parents=True, exist_ok=True)
    Path(NAMES_FILE).write_text(json.dumps(names, indent=2))


def set_friendly_name(mac: str, name: str) -> None:
    names = load_names()
    names[mac] = name
    save_names(names)


# ---------------------------------------------------------------------------
# Adapter type / capability detection
# ---------------------------------------------------------------------------

def is_wireless(iface: str) -> bool:
    """True if *iface* is a wireless (802.11) adapter."""
    base = Path("/sys/class/net") / iface
    if (base / "wireless").exists():
        return True
    if (base / "phy80211").exists():
        return True
    return False


def get_driver(iface: str) -> str:
    """Best-effort driver name for *iface* via sysfs (no ethtool dependency)."""
    driver_link = Path("/sys/class/net") / iface / "device" / "driver"
    try:
        return driver_link.resolve().name
    except Exception:
        return "unknown"


def is_physical(iface: str) -> bool:
    """True if *iface* backs a real hardware device (filters out VPN tunnels,
    bridges, veth pairs, etc. which show up under /sys/class/net too)."""
    return (Path("/sys/class/net") / iface / "device").exists()


# ---------------------------------------------------------------------------
# Known wireless chipset capability hints + USB VID:PID -> driver mapping
# ---------------------------------------------------------------------------
# Keyed by a lowercase substring of the kernel driver name. capabilities:
# ap, client, monitor (used for the 'pentest' role, which needs monitor mode).
CHIPSET_DB: dict[str, dict] = {
    # Common internal/onboard Broadcom radios (laptops, SBCs)
    "brcmfmac": {"chipset": "Broadcom BCM43xx (internal)",
                 "ap": True, "client": True, "monitor": False,
                 "note": "Internal/onboard radio. Monitor mode usually needs "
                         "out-of-tree nexmon firmware."},
    # TP-Link Archer T3U / T3U Nano / T3U Plus (Realtek RTL8812BU/8822BU)
    "88x2bu": {"chipset": "Realtek RTL8812BU (Archer T3U)",
               "ap": True, "client": True, "monitor": False,
               "note": "AC1300 dual-band. Great AP/client; monitor mode is "
                       "experimental/unstable on this chipset. Out-of-tree "
                       "driver -- run driver_setup.sh."},
    "rtl88x2bu": {"chipset": "Realtek RTL8812BU (Archer T3U)",
                  "ap": True, "client": True, "monitor": False,
                  "note": "AC1300 dual-band. Monitor mode experimental. "
                          "Out-of-tree driver -- run driver_setup.sh."},
    # ALFA AWUS036ACH / AWUS036AC (RTL8812AU) on the aircrack 88XXau driver.
    "88xxau": {"chipset": "Realtek RTL8812AU (ALFA AWUS036ACH)",
               "ap": True, "client": True, "monitor": True,
               "note": "AC1200 2x2 dual-band. Reliable monitor mode + "
                       "injection on the aircrack 88XXau driver, incl. "
                       "5 GHz. Out-of-tree driver (rebuild after kernel "
                       "upgrades) -- run driver_setup.sh."},
    "8812au": {"chipset": "Realtek RTL8812AU (ALFA AWUS036ACH)",
               "ap": True, "client": True, "monitor": True,
               "note": "AC1200 2x2 dual-band. Reliable monitor mode + "
                       "injection with the aircrack 88XXau driver."},
    # ALFA AWUS036AXM / AWUS036AXML (MediaTek MT7921AU, Wi-Fi 6 / 6E).
    # In-kernel mt76/mt7921u driver since Linux 5.18 -- no DKMS needed, but
    # needs the mt7921-series firmware blobs from linux-firmware.
    "mt7921u": {"chipset": "MediaTek MT7921AU (ALFA AWUS036AXM/AXML)",
                "ap": True, "client": True, "monitor": True,
                "note": "Wi-Fi 6/6E, in-kernel mt7921u driver (needs kernel "
                        "5.18+ and an up-to-date linux-firmware package). "
                        "Run driver_setup.sh to verify firmware/kernel."},
}

# USB VID:PID -> driver mapping, used to tell "adapter plugged in but its
# kernel module never bound" apart from "adapter not plugged in at all".
# Keyed by lowercase "vendor:product" as reported by `lsusb`.
USB_DRIVER_DB: dict[str, dict] = {
    # TP-Link Archer T3U / T3U Nano / T3U Plus. Out-of-tree -- needs 88x2bu.
    "2357:012d": {"name": "TP-Link Archer T3U", "module": "88x2bu", "dkms": True},
    "2357:012e": {"name": "TP-Link Archer T3U Nano", "module": "88x2bu", "dkms": True},
    "2357:0138": {"name": "TP-Link Archer T3U Plus", "module": "88x2bu", "dkms": True},
    # ALFA AWUS036ACH / AWUS036AC. Out-of-tree -- needs 88XXau/rtl8812au.
    "0bda:8812": {"name": "ALFA AWUS036ACH/AC (RTL8812AU)", "module": "88XXau", "dkms": True},
    # ALFA AWUS036AXM / AWUS036AXML. In-kernel since 5.18; only needs firmware.
    "0e8d:7961": {"name": "ALFA AWUS036AXM/AXML (MT7921AU)", "module": "mt7921u", "dkms": False},
}


def get_chipset_info(driver: str) -> dict | None:
    """Look up CHIPSET_DB capability hints for a resolved driver name."""
    if not driver:
        return None
    low = driver.lower()
    for key, meta in CHIPSET_DB.items():
        if key in low:
            return meta
    return None


def _lsusb_devices() -> list[tuple[str, str]]:
    """Parse `lsusb` into a list of (vendor:product lowercase, description)."""
    import shutil as _shutil
    import re as _re
    if not _shutil.which("lsusb"):
        return []
    try:
        r = subprocess.run(["lsusb"], capture_output=True, text=True, timeout=10)
    except Exception:
        return []
    if r.returncode != 0:
        return []
    out = []
    for line in r.stdout.splitlines():
        m = _re.search(r"ID\s+([0-9a-fA-F]{4}):([0-9a-fA-F]{4})\s*(.*)$", line)
        if m:
            vid, pid, desc = m.groups()
            out.append((f"{vid.lower()}:{pid.lower()}", desc.strip()))
    return out


def _bound_driver_modules() -> set[str]:
    """Kernel driver modules currently bound to ANY /sys/class/net device."""
    base = Path("/sys/class/net")
    mods: set[str] = set()
    if not base.is_dir():
        return mods
    for iface in base.iterdir():
        drv = get_driver(iface.name)
        if drv and drv != "unknown":
            mods.add(drv.lower())
    return mods


def detect_missing_drivers() -> list[dict]:
    """Adapters visible to the USB bus (lsusb) that match a KNOWN chipset in
    USB_DRIVER_DB but whose kernel module never bound to a net device --
    i.e. the adapter is physically present but has no wlan* interface
    because its driver (often an out-of-tree DKMS one) isn't installed or
    isn't loaded. This is the #1 cause of "AP never starts / uplink never
    comes up": netmgr-boot.sh/ap_manager.py only ever see interfaces that
    already exist in /sys/class/net, so a driverless adapter is silently
    invisible, not just misconfigured. See driver_setup.sh.
    """
    bound = _bound_driver_modules()
    missing = []
    seen = set()
    for vidpid, desc in _lsusb_devices():
        meta = USB_DRIVER_DB.get(vidpid)
        if not meta or vidpid in seen:
            continue
        if meta["module"].lower() not in bound:
            seen.add(vidpid)
            missing.append({
                "vid_pid": vidpid,
                "name": meta["name"],
                "module": meta["module"],
                "dkms": meta["dkms"],
                "usb_desc": desc,
                "fix": (f"Run 'sudo ./driver_setup.sh' (or the Install/Update "
                        f"Wireless Drivers button) to build/install the "
                        f"{meta['module']} DKMS driver." if meta["dkms"] else
                        f"Run 'sudo ./driver_setup.sh' to check kernel/"
                        f"firmware support for {meta['module']}."),
            })
    return missing


def _default_friendly_name(iface: str, adapter_type: str, index: int) -> str:
    if adapter_type == "wireless":
        return f"Wi-Fi Adapter {index}"
    return f"Ethernet Adapter {index}"


def discover_adapters() -> list[dict]:
    """
    Enumerate every physical network adapter and return rich metadata:
    {name, mac, type, driver, state, role, friendly_name, suggested_role}.

    This never auto-assigns the ethernet adapter as a default role (the
    common use case here is wireless-first); ethernet is always reported
    as a candidate that must be assigned explicitly (e.g. via the web GUI)
    if the operator wants to use it.
    """
    roles = load_roles()
    names = load_names()
    adapters: list[dict] = []
    base = Path("/sys/class/net")

    wifi_idx = 0
    eth_idx = 0
    for iface in sorted(base.iterdir()):
        if iface.name == "lo":
            continue
        if not is_physical(iface.name):
            continue
        mac_path = iface / "address"
        if not mac_path.exists():
            continue
        mac = mac_path.read_text().strip()
        state_path = iface / "operstate"
        state = state_path.read_text().strip() if state_path.exists() else "unknown"
        wireless = is_wireless(iface.name)
        adapter_type = "wireless" if wireless else "ethernet"

        if wireless:
            wifi_idx += 1
            idx = wifi_idx
        else:
            eth_idx += 1
            idx = eth_idx

        friendly = names.get(mac) or _default_friendly_name(iface.name, adapter_type, idx)
        role = roles.get(mac) or roles.get(iface.name, "unassigned")

        driver = get_driver(iface.name)
        chip = get_chipset_info(driver) if wireless else None

        adapters.append({
            "name": iface.name,
            "mac": mac,
            "type": adapter_type,
            "driver": driver,
            "chipset": chip["chipset"] if chip else None,
            "cap_ap": chip["ap"] if chip else None,
            "cap_client": chip["client"] if chip else None,
            "cap_monitor": chip["monitor"] if chip else None,
            "note": chip["note"] if chip else "",
            "state": state,
            "role": role,
            "friendly_name": friendly,
        })

    # Suggest roles for anything still unassigned. Wireless-first: ethernet
    # is NEVER auto-suggested for a role, it must be set explicitly.
    assigned_roles = {a["role"] for a in adapters if a["role"] != "unassigned"}
    wireless_unassigned = [a for a in adapters if a["type"] == "wireless" and a["role"] == "unassigned"]
    suggestion_order = ["uplink", "client", "ap", "pentest"]
    next_suggestions = [r for r in suggestion_order if r not in assigned_roles]
    for adapter, suggestion in zip(wireless_unassigned, next_suggestions):
        adapter["suggested_role"] = suggestion
    for adapter in adapters:
        adapter.setdefault("suggested_role", None)

    return adapters


def discover_and_autofill(assign_roles: bool = False) -> list[dict]:
    """
    Run discovery, persist default friendly names for any adapter missing
    one, and optionally auto-assign the suggested role for wireless
    adapters that have no role yet. Ethernet adapters are never
    auto-assigned a role; they stay 'unassigned' until the operator picks
    one in the web GUI.
    """
    adapters = discover_adapters()
    names = load_names()
    roles = load_roles()
    changed_names = False
    changed_roles = False

    for adapter in adapters:
        if adapter["mac"] not in names:
            names[adapter["mac"]] = adapter["friendly_name"]
            changed_names = True
        if (
            assign_roles
            and adapter["type"] == "wireless"
            and adapter["role"] == "unassigned"
            and adapter["suggested_role"]
        ):
            roles[adapter["mac"]] = adapter["suggested_role"]
            adapter["role"] = adapter["suggested_role"]
            changed_roles = True

    if changed_names:
        save_names(names)
    if changed_roles:
        save_roles(roles)

    return adapters


def list_adapters() -> list[dict]:
    """
    Return a list of {name, mac, role, state, friendly_name} for every
    physical network adapter. Resolves role by MAC first (stable), falls
    back to interface name.
    """
    roles = load_roles()
    names = load_names()
    adapters = []
    base = Path("/sys/class/net")
    for iface in sorted(base.iterdir()):
        # Skip virtual/loopback and non-physical interfaces (VPN tunnels, etc.)
        if iface.name == "lo":
            continue
        if not is_physical(iface.name):
            continue
        mac_path = iface / "address"
        if not mac_path.exists():
            continue
        mac = mac_path.read_text().strip()
        state_path = iface / "operstate"
        state = state_path.read_text().strip() if state_path.exists() else "unknown"
        role = roles.get(mac) or roles.get(iface.name, "unassigned")
        friendly_name = names.get(mac, iface.name)
        adapter_type = "wireless" if is_wireless(iface.name) else "ethernet"
        driver = get_driver(iface.name)
        chip = get_chipset_info(driver) if adapter_type == "wireless" else None
        adapters.append({
            "name": iface.name,
            "mac": mac,
            "role": role,
            "state": state,
            "friendly_name": friendly_name,
            "type": adapter_type,
            "driver": driver,
            "chipset": chip["chipset"] if chip else None,
            "cap_ap": chip["ap"] if chip else None,
            "cap_client": chip["client"] if chip else None,
            "cap_monitor": chip["monitor"] if chip else None,
            "note": chip["note"] if chip else "",
        })
    return adapters


def set_role(mac: str, role: str) -> None:
    if role not in VALID_ROLES:
        raise ValueError(f"Invalid role '{role}'. Must be one of {VALID_ROLES}")
    roles = load_roles()
    # Uplink protection: warn caller if they're re-assigning the current uplink
    for k, v in roles.items():
        if v == "uplink" and k == mac and role != "uplink":
            logger.warning("Changing uplink adapter role – operator confirmed.")
    roles[mac] = role
    save_roles(roles)


# ---------------------------------------------------------------------------
# Bridge builder
# ---------------------------------------------------------------------------

def bridge_add(iface: str, bridge: str = "br0") -> None:
    """Add an interface to a Linux bridge (via privileged helper)."""
    _require_not_uplink(iface)
    _call_helper("bridge-add", bridge, iface)
    logger.info("Added %s to bridge %s", iface, bridge)


def bridge_remove(iface: str, bridge: str = "br0") -> None:
    _call_helper("bridge-remove", bridge, iface)
    logger.info("Removed %s from bridge %s", iface, bridge)


def list_bridge_members(bridge: str = "br0") -> list[str]:
    try:
        result = subprocess.run(
            ["ip", "link", "show", "master", bridge],
            capture_output=True, text=True, timeout=5
        )
        members = []
        for line in result.stdout.splitlines():
            if "@" in line:
                members.append(line.split(":")[1].strip().split("@")[0])
        return members
    except Exception as exc:
        logger.error("Could not list bridge members: %s", exc)
        return []


# ---------------------------------------------------------------------------
# Wi-Fi client (priority list)
# ---------------------------------------------------------------------------

def load_wifi_networks() -> list[dict]:
    try:
        return json.loads(Path(WIFI_FILE).read_text())
    except FileNotFoundError:
        return []


def save_wifi_networks(networks: list[dict]) -> None:
    Path(WIFI_FILE).parent.mkdir(parents=True, exist_ok=True)
    Path(WIFI_FILE).write_text(json.dumps(networks, indent=2))


def add_wifi_network(ssid: str, psk: str, priority: int = 0) -> None:
    networks = load_wifi_networks()
    networks = [n for n in networks if n.get("ssid") != ssid]  # deduplicate
    networks.append({"ssid": ssid, "psk": psk, "priority": priority, "enabled": True})
    networks.sort(key=lambda n: n.get("priority", 0), reverse=True)
    save_wifi_networks(networks)
    _call_helper("wifi-reload")


def remove_wifi_network(ssid: str) -> None:
    networks = [n for n in load_wifi_networks() if n.get("ssid") != ssid]
    save_wifi_networks(networks)
    _call_helper("wifi-reload")


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _require_not_uplink(iface: str) -> None:
    roles = load_roles()
    adapters = list_adapters()
    for a in adapters:
        if a["name"] == iface and roles.get(a["mac"]) == "uplink":
            raise PermissionError(
                f"Adapter {iface} is tagged as 'uplink' and is protected from bridging. "
                "Use set_role() to change this first and confirm you understand the risk."
            )


def _call_helper(action: str, *args: str) -> None:
    cmd = [HELPER_BIN, action, *args]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    if result.returncode != 0:
        raise RuntimeError(f"Helper failed [{action}]: {result.stderr.strip()}")

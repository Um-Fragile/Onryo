#!/bin/bash
# Onryo network manager – boot-time network setup.
# Reads /etc/onryo/network-roles.json and /etc/onryo/wifi-networks.json,
# assigns roles, and brings up the management AP, uplink, and client
# connections.
#
# IMPORTANT ordering/behavior guarantees:
#   1. The management AP (role "ap") is always created and started if an
#      adapter is assigned that role, REGARDLESS of whether the uplink is
#      connected. The AP must never be gated on uplink status.
#   2. The uplink (role "uplink") can be either wired (ethernet) or
#      wireless. If it is wireless, it is connected using the same
#      saved-network list as the "client" role. Ethernet is never assumed
#      or defaulted to anywhere in this script; it is only used if an
#      operator has explicitly assigned the "uplink"/"client" role to an
#      ethernet adapter (normally done from the web GUI).

set -uo pipefail
LOG="/var/log/onryo/netmgr.log"
mkdir -p "$(dirname "$LOG")"

log() { echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) [netmgr] $*" | tee -a "$LOG"; }

ONRYO_HOME="${ONRYO_HOME:-/opt/onryo}"
ROLES_FILE="/etc/onryo/network-roles.json"
WIFI_FILE="/etc/onryo/wifi-networks.json"

log "Onryo network manager starting"

if [[ ! -f "$ROLES_FILE" ]]; then
  log "No roles file at $ROLES_FILE – skipping network setup"
  exit 0
fi

log "Roles file found: $ROLES_FILE"

# Parse roles using python (already installed as a dependency)
ONRYO_HOME="$ONRYO_HOME" python3 - <<'PYEOF'
import json, subprocess, sys, os, pathlib

ONRYO_HOME = os.environ.get("ONRYO_HOME", "/opt/onryo")
sys.path.insert(0, ONRYO_HOME)
sys.path.insert(0, os.path.join(ONRYO_HOME, "backend"))

ROLES_FILE = "/etc/onryo/network-roles.json"
WIFI_FILE  = "/etc/onryo/wifi-networks.json"

try:
    roles = json.loads(open(ROLES_FILE).read())
except Exception as e:
    print(f"[netmgr] Failed to read roles: {e}")
    sys.exit(0)


def resolve_iface(mac):
    for p in pathlib.Path("/sys/class/net").iterdir():
        try:
            addr = (p / "address").read_text().strip()
            if addr == mac:
                return p.name
        except Exception:
            pass
    return None


def is_wireless(iface):
    base = pathlib.Path("/sys/class/net") / iface
    return (base / "wireless").exists() or (base / "phy80211").exists()


def run(*cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print(f"[netmgr] WARN: {' '.join(cmd)} -> {r.stderr.strip()}")
    return r


uplink_iface  = None
client_iface  = None
ap_iface      = None
pentest_iface = None

for mac, role in roles.items():
    iface = resolve_iface(mac) or mac
    print(f"[netmgr] {mac} -> {iface} ({role})")
    if role == "uplink":  uplink_iface  = iface
    if role == "client":  client_iface  = iface
    if role == "ap":      ap_iface      = iface
    if role == "pentest": pentest_iface = iface

# ---------------------------------------------------------------------
# 1. Management / bridge AP – ALWAYS created and started if an "ap"
#    adapter is assigned, independent of uplink connectivity. This must
#    run first and must not be short-circuited by failures elsewhere.
# ---------------------------------------------------------------------
if ap_iface:
    try:
        from network_manager.ap_manager import APManager
        from network_manager.network_manager import bridge_add

        ap_mgr = APManager()
        cfg = ap_mgr.get_config()
        cfg["iface"] = ap_iface
        ap_mgr.save_config(cfg)

        # Bridge AP: if the saved config requests a bridge, make sure the
        # bridge device exists first so hostapd's bridge= directive can
        # attach the AP interface to it on start.
        bridge_name = cfg.get("bridge")
        if bridge_name:
            print(f"[netmgr] Ensuring bridge {bridge_name} exists for AP {ap_iface}")
            run("ip", "link", "add", "name", bridge_name, "type", "bridge")
            run("ip", "link", "set", bridge_name, "up")

        print(f"[netmgr] Starting management AP on {ap_iface} (regardless of uplink status)")
        ok, msg = ap_mgr.start()
        if ok:
            print(f"[netmgr] Management AP started on {ap_iface}: {msg}")
        else:
            print(f"[netmgr] WARN: Management AP failed to start on {ap_iface}: {msg}")
    except Exception as exc:
        print(f"[netmgr] WARN: Exception while starting management AP: {exc}")
else:
    print("[netmgr] No adapter assigned the 'ap' role – skipping management AP")

# ---------------------------------------------------------------------
# 2. Wireless connections. Both "uplink" and "client" roles can be a
#    wireless adapter; only wireless adapters are ever auto-connected
#    here. Wired ethernet is never assumed/defaulted to -- it is only
#    brought up by NetworkManager's own normal device handling, and is
#    configured explicitly via the web GUI if the operator wants to use
#    it.
# ---------------------------------------------------------------------
try:
    wifi = json.loads(open(WIFI_FILE).read())
except Exception:
    wifi = []
wifi_sorted = sorted(wifi, key=lambda n: -n.get("priority", 0))

wireless_candidates = []
if uplink_iface and is_wireless(uplink_iface):
    wireless_candidates.append(("uplink", uplink_iface))
elif uplink_iface:
    print(f"[netmgr] Uplink adapter {uplink_iface} is wired (ethernet) – leaving to NetworkManager")

if client_iface and is_wireless(client_iface):
    wireless_candidates.append(("client", client_iface))
elif client_iface:
    print(f"[netmgr] Client adapter {client_iface} is wired (ethernet) – leaving to NetworkManager")

for role_name, iface in wireless_candidates:
    connected = False
    for net in wifi_sorted:
        if not net.get("enabled", True):
            continue
        ssid = net.get("ssid", "")
        psk  = net.get("psk", "")
        print(f"[netmgr] ({role_name}) Attempting connection to SSID: {ssid} via {iface}")
        r = run("nmcli", "device", "wifi", "connect", ssid, "password", psk, "ifname", iface)
        if r.returncode == 0:
            print(f"[netmgr] ({role_name}) Connected to {ssid} via {iface}")
            connected = True
            break
    if not connected:
        print(f"[netmgr] ({role_name}) Could not connect {iface} to any saved network")

# Leave pentest adapter unmanaged (NM hands-off)
if pentest_iface:
    run("nmcli", "device", "set", pentest_iface, "managed", "no")
    print(f"[netmgr] {pentest_iface} set unmanaged (pentest mode)")

print("[netmgr] Boot-time network setup complete")
PYEOF

log "Network manager boot complete"

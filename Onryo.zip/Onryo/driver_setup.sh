#!/usr/bin/env bash
# Onryo - driver_setup.sh
#
# Installs/updates the out-of-tree kernel drivers for the wireless adapters
# this deployment targets, and sanity-checks the in-kernel one:
#
#   TP-Link Archer T3U / T3U Nano / T3U Plus   (RTL8812BU/8822BU) -> 88x2bu
#   ALFA AWUS036ACH / AWUS036AC                 (RTL8812AU)       -> 88XXau
#   ALFA AWUS036AXM / AWUS036AXML               (MT7921AU)        -> mt7921u (in-kernel)
#
# Why this exists: onryo-netmgr.service and backend/network_manager/*.py
# only ever operate on interfaces that ALREADY exist in /sys/class/net. If
# a USB adapter's kernel module never loaded (true by default for both
# Realtek chipsets above -- Debian/Ubuntu ship no driver for them at all),
# the adapter never becomes a wlan* interface: no AP, no uplink, no client
# connection, and 'Discover Devices' simply won't list it. This is not a
# role/config problem, the adapter is invisible to Linux until its driver
# is installed.
#
# All wireless-adapter driver detection/installation lives HERE, in the
# base Onryo project -- NOT in any plugin. Plugins (e.g. the Vision WiFi
# plugin) only ever present a selection UI over whatever adapters Onryo
# core has already discovered and made available; they must never re-detect
# chipsets or install drivers themselves.
#
# Safe to re-run: every step is idempotent. Must run as root.
#
# Usage: sudo ./driver_setup.sh [--skip-88x2bu] [--skip-88xxau] [--skip-mediatek]

set -uo pipefail  # NOT -e: one failed driver must not abort the others.

SKIP_REALTEK_BU=0
SKIP_REALTEK_AU=0
SKIP_MEDIATEK=0
for arg in "$@"; do
  case "$arg" in
    --skip-realtek) SKIP_REALTEK_BU=1; SKIP_REALTEK_AU=1 ;;
    --skip-88x2bu)  SKIP_REALTEK_BU=1 ;;
    --skip-88xxau)  SKIP_REALTEK_AU=1 ;;
    --skip-mediatek|--skip-mt7921u) SKIP_MEDIATEK=1 ;;
    *) echo "[driver-setup] Unknown option: $arg" >&2; exit 1 ;;
  esac
done

SRC_DIR="/usr/src"
LOG_FILE="/var/log/onryo/driver-setup.log"
mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true

LOG() { echo "[driver-setup] $*" | tee -a "$LOG_FILE" 2>/dev/null || echo "[driver-setup] $*"; }
WARN() { echo "[driver-setup] WARNING: $*" | tee -a "$LOG_FILE" >&2 2>/dev/null || echo "[driver-setup] WARNING: $*" >&2; }
FAIL_SOFT() { echo "[driver-setup] ERROR (continuing): $*" | tee -a "$LOG_FILE" >&2 2>/dev/null || echo "[driver-setup] ERROR (continuing): $*" >&2; }

if [[ $EUID -ne 0 ]]; then
  echo "[driver-setup] Must run as root (sudo ./driver_setup.sh)" >&2
  exit 1
fi

KERNEL="$(uname -r)"
LOG "Running kernel: $KERNEL"

# --------------------------------------------------------------------------- #
# 0. Build dependencies shared by both DKMS drivers.
# --------------------------------------------------------------------------- #
LOG "Installing build dependencies (dkms, headers, git, build tools)..."
apt-get update -qq || WARN "apt-get update failed; continuing with cached indexes"
apt-get install -y --no-install-recommends \
    dkms build-essential bc git libelf-dev python3 \
    "linux-headers-${KERNEL}" 2>/dev/null \
  || apt-get install -y --no-install-recommends "linux-headers-generic" 2>/dev/null \
  || WARN "Could not install kernel headers automatically for ${KERNEL}. \
Driver builds below may fail until headers matching this kernel are installed \
(try: sudo apt-get install linux-headers-\$(uname -r))."

_dkms_installed() {
  dkms status 2>/dev/null | grep -qi "^$1"
}

_clone_or_update() {
  local dest="$1" url="$2" ref="${3:-}"
  if [[ -d "$dest/.git" ]]; then
    LOG "Updating existing checkout at $dest ..."
    git -C "$dest" fetch --depth 1 origin "${ref:-HEAD}" 2>/dev/null || true
    git -C "$dest" pull --ff-only 2>/dev/null || true
  else
    LOG "Cloning $url -> $dest ..."
    rm -rf "$dest"
    git clone --depth 1 ${ref:+--branch "$ref"} "$url" "$dest" \
      || { FAIL_SOFT "git clone failed for $url"; return 1; }
  fi
  if [[ -n "$ref" ]]; then
    git -C "$dest" checkout "$ref" 2>/dev/null || true
  fi
  return 0
}

# --------------------------------------------------------------------------- #
# 1. TP-Link Archer T3U / T3U Nano / T3U Plus (Realtek RTL8812BU/8822BU, 88x2bu)
#    USB IDs: 2357:012d (T3U), 2357:012e (T3U Nano), 2357:0138 (T3U Plus)
# --------------------------------------------------------------------------- #
if [[ $SKIP_REALTEK_BU -eq 0 ]]; then
  LOG "=== TP-Link Archer T3U / T3U Nano driver (88x2bu) ==="
  if _dkms_installed "88x2bu"; then
    LOG "88x2bu already registered in dkms; skipping build."
  else
    DEST="$SRC_DIR/88x2bu-20210702"
    if _clone_or_update "$DEST" "https://github.com/morrownr/88x2bu-20210702.git"; then
      ( cd "$DEST" && ./install-driver.sh NoPrompt ) \
        || FAIL_SOFT "88x2bu install-driver.sh failed -- check kernel headers for $KERNEL"
    fi
  fi
  modprobe 88x2bu 2>/dev/null && LOG "88x2bu module loaded." \
    || WARN "88x2bu did not load (no adapter plugged in yet, or build failed above)."
else
  LOG "Skipping 88x2bu (TP-Link Archer T3U family) per flag."
fi

# --------------------------------------------------------------------------- #
# 2. ALFA AWUS036ACH / AWUS036AC (Realtek RTL8812AU, 88XXau)
#    USB ID: 0bda:8812
#    The in-kernel rtw88 driver can grab this ID first with worse monitor/
#    injection support, so we blacklist it in favor of the DKMS 88XXau build.
# --------------------------------------------------------------------------- #
if [[ $SKIP_REALTEK_AU -eq 0 ]]; then
  LOG "=== ALFA AWUS036ACH/AC driver (88XXau / rtl8812au) ==="
  if _dkms_installed "rtl8812au\|88xxau"; then
    LOG "rtl8812au/88XXau already registered in dkms; skipping build."
  else
    DEST="$SRC_DIR/rtl8812au"
    if _clone_or_update "$DEST" "https://github.com/aircrack-ng/rtl8812au.git"; then
      ( cd "$DEST" && make dkms_install ) \
        || FAIL_SOFT "rtl8812au dkms_install failed -- check kernel headers for $KERNEL"
    fi
  fi
  BLACKLIST_FILE="/etc/modprobe.d/onryo-blacklist-rtw88-8812au.conf"
  if [[ ! -f "$BLACKLIST_FILE" ]]; then
    LOG "Blacklisting in-kernel rtw88 8812au modules so 88XXau (DKMS) wins..."
    cat > "$BLACKLIST_FILE" <<'EOF'
# Installed by Onryo's driver_setup.sh.
# The in-kernel rtw88 driver has weaker monitor-mode/injection support for
# the RTL8812AU (ALFA AWUS036ACH/AC) than the aircrack-ng 88XXau DKMS driver.
# Remove this file if you want the in-kernel driver instead.
blacklist rtw88_8812au
blacklist rtw88_8812au_common
EOF
  fi
  modprobe -r rtw88_8812au 2>/dev/null || true
  modprobe 88XXau 2>/dev/null && LOG "88XXau module loaded." \
    || WARN "88XXau did not load (no adapter plugged in yet, or build failed above)."
else
  LOG "Skipping 88XXau (ALFA AWUS036ACH/AC) per flag."
fi

# --------------------------------------------------------------------------- #
# 3. ALFA AWUS036AXM / AWUS036AXML (MediaTek MT7921AU, mt7921u) - in-kernel
#    USB ID: 0e8d:7961
#    No DKMS build needed; just needs kernel >=5.18 and current firmware.
# --------------------------------------------------------------------------- #
if [[ $SKIP_MEDIATEK -eq 0 ]]; then
  LOG "=== ALFA AWUS036AXM/AXML driver (mt7921u, in-kernel) ==="
  KVER_MAJOR="$(echo "$KERNEL" | cut -d. -f1)"
  KVER_MINOR="$(echo "$KERNEL" | cut -d. -f2)"
  if (( KVER_MAJOR < 5 || (KVER_MAJOR == 5 && KVER_MINOR < 18) )); then
    WARN "Kernel $KERNEL is older than 5.18 -- mt7921u may be missing or \
buggy. Upgrade the kernel (sudo apt-get update && sudo apt-get full-upgrade) \
for AWUS036AXML support."
  else
    LOG "Kernel $KERNEL >= 5.18: mt7921u should be present in-kernel."
  fi
  apt-get install -y --no-install-recommends linux-firmware 2>/dev/null \
    || WARN "Could not install/update linux-firmware via apt (may already be current, or package name differs on this distro)."
  if modprobe mt7921u 2>/dev/null; then
    LOG "mt7921u module loaded."
  else
    WARN "mt7921u did not load. If the adapter is plugged in, check: \
dmesg | grep -i mt7921  (firmware load failures show up there)."
  fi
else
  LOG "Skipping mt7921u (ALFA AWUS036AXM/AXML) per flag."
fi

LOG ""
LOG "Done. Re-plug any adapter that was already connected before this run so"
LOG "its driver binds, then re-run 'Discover Devices' in the Network page, or:"
LOG "  ip link show | grep wlan"
LOG "  lsusb"
LOG "  dmesg | tail -40"
